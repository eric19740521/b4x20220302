package b4a.example3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class client extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example3.client");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example3.client.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public b4a.example3.servermanager _mmanager = null;
public b4a.example3.main _main = null;
public b4a.example3.starter _starter = null;
public String  _astream_error() throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Private Sub AStream_Error";
 //BA.debugLineNum = 55;BA.debugLine="Log(\"AStream_Error==>\")";
__c.LogImpl("05177345","AStream_Error==>",0);
 //BA.debugLineNum = 57;BA.debugLine="mManager.ClientDisconnected(Me)";
_mmanager._clientdisconnected /*String*/ ((b4a.example3.client)(this));
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public String  _astream_newdata(byte[] _buffer) throws Exception{
String _s = "";
String _line = "";
 //BA.debugLineNum = 31;BA.debugLine="Private Sub AStream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 32;BA.debugLine="Log(\"AStream_NewData==>\")";
__c.LogImpl("05046273","AStream_NewData==>",0);
 //BA.debugLineNum = 34;BA.debugLine="Dim s As String = BytesToString(Buffer, 0, Buffer";
_s = __c.BytesToString(_buffer,(int) (0),_buffer.length,"ASCII");
 //BA.debugLineNum = 36;BA.debugLine="Log(\"s: \"&s)";
__c.LogImpl("05046277","s: "+_s,0);
 //BA.debugLineNum = 37;BA.debugLine="For Each line As String In Regex.Split(\"\\n\", s)";
{
final String[] group4 = __c.Regex.Split("\\n",_s);
final int groupLen4 = group4.length
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_line = group4[index4];
 //BA.debugLineNum = 38;BA.debugLine="If line.StartsWith(\"GET\") Then";
if (_line.startsWith("GET")) { 
 //BA.debugLineNum = 40;BA.debugLine="If line.Trim <> \"GET / HTTP/1.1\" Then";
if ((_line.trim()).equals("GET / HTTP/1.1") == false) { 
 //BA.debugLineNum = 41;BA.debugLine="Log(line)";
__c.LogImpl("05046282",_line,0);
 //BA.debugLineNum = 42;BA.debugLine="astream.Close";
_astream.Close();
 };
 };
 }
};
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Private Sub AStream_Terminated";
 //BA.debugLineNum = 49;BA.debugLine="Log(\"AStream_Terminated==>\")";
__c.LogImpl("05111809","AStream_Terminated==>",0);
 //BA.debugLineNum = 51;BA.debugLine="AStream_Error";
_astream_error();
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 3;BA.debugLine="Private mManager As ServerManager";
_mmanager = new b4a.example3.servermanager();
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.SocketWrapper _socket,b4a.example3.servermanager _manager) throws Exception{
innerInitialize(_ba);
String _s = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Sub Initialize (socket As Socket, manager A";
 //BA.debugLineNum = 7;BA.debugLine="Log(\"clients Initialize==>\")";
__c.LogImpl("04915201","clients Initialize==>",0);
 //BA.debugLineNum = 10;BA.debugLine="mManager = manager";
_mmanager = _manager;
 //BA.debugLineNum = 11;BA.debugLine="astream.Initialize(socket.InputStream, socket.Out";
_astream.Initialize(ba,_socket.getInputStream(),_socket.getOutputStream(),"astream");
 //BA.debugLineNum = 12;BA.debugLine="Dim s As String = $\"HTTP/1.0 200 OK Cache-Control";
_s = ("HTTP/1.0 200 OK\n"+"Cache-Control: no-cache\n"+"Pragma: no-cache\n"+"Content-Type: multipart/x-mixed-replace; boundary=--myboundary\n"+"\n"+"");
 //BA.debugLineNum = 19;BA.debugLine="Log(\"clients 送出表頭==>HTTP/1.0 200 OK\")";
__c.LogImpl("04915213","clients 送出表頭==>HTTP/1.0 200 OK",0);
 //BA.debugLineNum = 20;BA.debugLine="astream.Write(s.Replace(CRLF, Starter.EOL).GetByt";
_astream.Write(_s.replace(__c.CRLF,_starter._eol /*String*/ ).getBytes("ASCII"));
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _newframe(byte[] _header,byte[] _data) throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Public Sub NewFrame (header() As Byte, data() As B";
 //BA.debugLineNum = 26;BA.debugLine="astream.Write(header)";
_astream.Write(_header);
 //BA.debugLineNum = 27;BA.debugLine="astream.Write(data)";
_astream.Write(_data);
 //BA.debugLineNum = 28;BA.debugLine="astream.Write(Starter.EOL.GetBytes(\"ASCII\"))";
_astream.Write(_starter._eol /*String*/ .getBytes("ASCII"));
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
