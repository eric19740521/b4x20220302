package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class mjpeg extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.mjpeg", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.mjpeg.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.SocketWrapper _sock = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public Object _mcallback = null;
public String _meventname = "";
public String _mhost = "";
public String _mpath = "";
public byte[] _data = null;
public int _index = 0;
public anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
public String _boundary = "";
public b4j.example.main _main = null;
public String  _astream_error() throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Private Sub AStream_Error";
 //BA.debugLineNum = 110;BA.debugLine="Log(\"AStream_Error==>\")";
__c.LogImpl("5720897","AStream_Error==>",0);
 //BA.debugLineNum = 112;BA.debugLine="Log(LastException.Message)";
__c.LogImpl("5720899",__c.LastException(ba).getMessage(),0);
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return "";
}
public String  _astream_newdata(byte[] _buffer) throws Exception{
int _i1 = 0;
int _i2 = 0;
String _ct = "";
int _b = 0;
int _b1 = 0;
int _b2 = 0;
int _startframe = 0;
int _endframe = 0;
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _bmp = null;
 //BA.debugLineNum = 49;BA.debugLine="Private Sub AStream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 50;BA.debugLine="Log(\"AStream_NewData==>\")";
__c.LogImpl("5458753","AStream_NewData==>",0);
 //BA.debugLineNum = 52;BA.debugLine="bc.ArrayCopy(Buffer, 0, Data, index, Buffer.Lengt";
_bc.ArrayCopy((Object)(_buffer),(int) (0),(Object)(_data),_index,_buffer.length);
 //BA.debugLineNum = 53;BA.debugLine="index = index + Buffer.Length";
_index = (int) (_index+_buffer.length);
 //BA.debugLineNum = 54;BA.debugLine="If boundary = \"\" Then";
if ((_boundary).equals("")) { 
 //BA.debugLineNum = 55;BA.debugLine="Dim i1 As Int = IndexOfString(\"Content-Type\", 0)";
_i1 = _indexofstring("Content-Type",(int) (0));
 //BA.debugLineNum = 56;BA.debugLine="If i1 > -1 Then";
if (_i1>-1) { 
 //BA.debugLineNum = 57;BA.debugLine="Dim i2 As Int = IndexOfString(CRLF, i1 + 1)";
_i2 = _indexofstring(__c.CRLF,(int) (_i1+1));
 //BA.debugLineNum = 58;BA.debugLine="If i2 > -1 Then";
if (_i2>-1) { 
 //BA.debugLineNum = 59;BA.debugLine="Dim ct As String = BytesToString(Data, i1, i2";
_ct = __c.BytesToString(_data,_i1,(int) (_i2-_i1),"ASCII");
 //BA.debugLineNum = 60;BA.debugLine="Dim b As Int = ct.IndexOf(\"=\")";
_b = _ct.indexOf("=");
 //BA.debugLineNum = 61;BA.debugLine="boundary = ct.SubString(b + 1)";
_boundary = _ct.substring((int) (_b+1));
 //BA.debugLineNum = 62;BA.debugLine="Log(\"boundary: \" & boundary)";
__c.LogImpl("5458765","boundary: "+_boundary,0);
 };
 };
 }else {
 //BA.debugLineNum = 66;BA.debugLine="Dim b1 As Int = IndexOfString(boundary, 0)";
_b1 = _indexofstring(_boundary,(int) (0));
 //BA.debugLineNum = 67;BA.debugLine="If b1 > -1 Then";
if (_b1>-1) { 
 //BA.debugLineNum = 68;BA.debugLine="Dim b2 As Int = IndexOfString(boundary, b1 + 1)";
_b2 = _indexofstring(_boundary,(int) (_b1+1));
 //BA.debugLineNum = 69;BA.debugLine="If b2 > -1 Then";
if (_b2>-1) { 
 //BA.debugLineNum = 70;BA.debugLine="Dim startframe As Int = IndexOf(Array As Byte(";
_startframe = _indexof(new byte[]{(byte) (((int)0xff)),(byte) (((int)0xd8))},_b1);
 //BA.debugLineNum = 71;BA.debugLine="Dim endframe As Int = IndexOf(Array As Byte(0x";
_endframe = _indexof(new byte[]{(byte) (((int)0xff)),(byte) (((int)0xd9))},(int) (_b2-10));
 //BA.debugLineNum = 72;BA.debugLine="If startframe > -1 And endframe > -1 Then";
if (_startframe>-1 && _endframe>-1) { 
 //BA.debugLineNum = 73;BA.debugLine="Dim In As InputStream";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 74;BA.debugLine="In.InitializeFromBytesArray(Data, startframe,";
_in.InitializeFromBytesArray(_data,_startframe,(int) (_endframe-_startframe+2));
 //BA.debugLineNum = 76;BA.debugLine="Dim bmp As Image";
_bmp = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 80;BA.debugLine="bmp.Initialize2(In)";
_bmp.Initialize2((java.io.InputStream)(_in.getObject()));
 //BA.debugLineNum = 81;BA.debugLine="CallSub2(mCallback, mEventName & \"_frame\", bm";
__c.CallSubNew2(ba,_mcallback,_meventname+"_frame",(Object)(_bmp));
 };
 //BA.debugLineNum = 83;BA.debugLine="TrimArray(b2)";
_trimarray(_b2);
 };
 };
 };
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="Private Sub Astream_Terminated";
 //BA.debugLineNum = 116;BA.debugLine="Log(\"Astream_Terminated==>\")";
__c.LogImpl("5786433","Astream_Terminated==>",0);
 //BA.debugLineNum = 118;BA.debugLine="Log(\"Astream: \" & LastException.Message)";
__c.LogImpl("5786435","Astream: "+__c.LastException(ba).getMessage(),0);
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private sock As Socket";
_sock = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private Astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 4;BA.debugLine="Private mCallback As Object";
_mcallback = new Object();
 //BA.debugLineNum = 5;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 6;BA.debugLine="Private mHost As String";
_mhost = "";
 //BA.debugLineNum = 7;BA.debugLine="Private mPath As String";
_mpath = "";
 //BA.debugLineNum = 8;BA.debugLine="Private Data(1000000) As Byte";
_data = new byte[(int) (1000000)];
;
 //BA.debugLineNum = 9;BA.debugLine="Private index As Int";
_index = 0;
 //BA.debugLineNum = 10;BA.debugLine="Private bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 11;BA.debugLine="Private boundary As String";
_boundary = "";
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _connect(String _url,int _port) throws Exception{
int _i = 0;
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Connect(url As String, Port As Int)";
 //BA.debugLineNum = 20;BA.debugLine="Log(\"Connect==>\")";
__c.LogImpl("5327681","Connect==>",0);
 //BA.debugLineNum = 22;BA.debugLine="If Astream.IsInitialized Then Astream.Close";
if (_astream.IsInitialized()) { 
_astream.Close();};
 //BA.debugLineNum = 23;BA.debugLine="Dim i As Int = url.IndexOf(\"/\")";
_i = _url.indexOf("/");
 //BA.debugLineNum = 24;BA.debugLine="mPath = url.SubString(i)";
_mpath = _url.substring(_i);
 //BA.debugLineNum = 25;BA.debugLine="mHost = url.SubString2(0, i)";
_mhost = _url.substring((int) (0),_i);
 //BA.debugLineNum = 27;BA.debugLine="Log(\"mPath: \"&mPath)";
__c.LogImpl("5327688","mPath: "+_mpath,0);
 //BA.debugLineNum = 28;BA.debugLine="Log(\"mHost : \"&mHost )";
__c.LogImpl("5327689","mHost : "+_mhost,0);
 //BA.debugLineNum = 30;BA.debugLine="sock.Initialize(\"sock\")";
_sock.Initialize("sock");
 //BA.debugLineNum = 31;BA.debugLine="sock.Connect(mHost, Port, 30000)";
_sock.Connect(ba,_mhost,_port,(int) (30000));
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public int  _indexof(byte[] _bs,int _start) throws Exception{
int _i = 0;
int _b = 0;
 //BA.debugLineNum = 99;BA.debugLine="Private Sub IndexOf(bs() As Byte, Start As Int) As";
 //BA.debugLineNum = 100;BA.debugLine="For i = Start To index - 1 - bs.Length";
{
final int step1 = 1;
final int limit1 = (int) (_index-1-_bs.length);
_i = _start ;
for (;_i <= limit1 ;_i = _i + step1 ) {
 //BA.debugLineNum = 101;BA.debugLine="For b = 0 To bs.Length - 1";
{
final int step2 = 1;
final int limit2 = (int) (_bs.length-1);
_b = (int) (0) ;
for (;_b <= limit2 ;_b = _b + step2 ) {
 //BA.debugLineNum = 102;BA.debugLine="If bs(b) <> Data(i + b) Then Exit";
if (_bs[_b]!=_data[(int) (_i+_b)]) { 
if (true) break;};
 }
};
 //BA.debugLineNum = 104;BA.debugLine="If b = bs.Length Then Return i";
if (_b==_bs.length) { 
if (true) return _i;};
 }
};
 //BA.debugLineNum = 106;BA.debugLine="Return -1";
if (true) return (int) (-1);
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return 0;
}
public int  _indexofstring(String _s,int _start) throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Private Sub IndexOfString(s As String, Start As In";
 //BA.debugLineNum = 96;BA.debugLine="Return IndexOf(s.GetBytes(\"ASCII\"), Start)";
if (true) return _indexof(_s.getBytes("ASCII"),_start);
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 15;BA.debugLine="mCallback = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 16;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _sock_connected(boolean _successful) throws Exception{
String _stmp = "";
 //BA.debugLineNum = 35;BA.debugLine="Private Sub Sock_Connected (Successful As Boolean)";
 //BA.debugLineNum = 36;BA.debugLine="Log(\"Sock_Connected==>\")";
__c.LogImpl("5393217","Sock_Connected==>",0);
 //BA.debugLineNum = 37;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 38;BA.debugLine="boundary = \"\"";
_boundary = "";
 //BA.debugLineNum = 39;BA.debugLine="Astream.Initialize(sock.InputStream, sock.Output";
_astream.Initialize(ba,_sock.getInputStream(),_sock.getOutputStream(),"astream");
 //BA.debugLineNum = 40;BA.debugLine="Dim sTmp As String = $\"GET ${mPath} HTTP/1.1 Hos";
_stmp = ("GET "+__c.SmartStringFormatter("",(Object)(_mpath))+" HTTP/1.1\n"+"Host: "+__c.SmartStringFormatter("",(Object)(_mhost))+"\n"+"Connection: keep-alive\n"+"\n"+"");
 //BA.debugLineNum = 45;BA.debugLine="Astream.Write(sTmp.Replace(Chr(10), Chr(13) & Ch";
_astream.Write(_stmp.replace(BA.ObjectToString(__c.Chr((int) (10))),BA.ObjectToString(__c.Chr((int) (13)))+BA.ObjectToString(__c.Chr((int) (10)))).getBytes("UTF8"));
 };
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public String  _trimarray(int _i) throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Private Sub TrimArray (i As Int)";
 //BA.debugLineNum = 91;BA.debugLine="bc.ArrayCopy(Data, i, Data, 0, index - i)";
_bc.ArrayCopy((Object)(_data),_i,(Object)(_data),(int) (0),(int) (_index-_i));
 //BA.debugLineNum = 92;BA.debugLine="index = index - i";
_index = (int) (_index-_i);
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
