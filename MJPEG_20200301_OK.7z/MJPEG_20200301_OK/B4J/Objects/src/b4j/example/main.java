package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 800, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static b4j.example.mjpeg _mj1 = null;
public static anywheresoftware.b4j.objects.ImageViewWrapper _imageview1 = null;
public static anywheresoftware.b4j.objects.ImageViewWrapper _imageview2 = null;
public static anywheresoftware.b4j.objects.ImageViewWrapper _imageview3 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 17;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 18;BA.debugLine="MainForm.RootPane.LoadLayout(\"1\")";
_mainform.getRootPane().LoadLayout(ba,"1");
 //BA.debugLineNum = 19;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 20;BA.debugLine="mj1.Initialize(Me, \"mj1\")";
_mj1._initialize /*String*/ (ba,main.getObject(),"mj1");
 //BA.debugLineNum = 21;BA.debugLine="mj1.Connect(\"192.168.1.166/\", 51042) 'this stream";
_mj1._connect /*String*/ ("192.168.1.166/",(int) (51042));
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _mj1_frame(anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _bmp) throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Sub mj1_Frame(bmp As Image)";
 //BA.debugLineNum = 29;BA.debugLine="ImageView1.SetImage(bmp)";
_imageview1.SetImage((javafx.scene.image.Image)(_bmp.getObject()));
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private mj1 As MJPEG";
_mj1 = new b4j.example.mjpeg();
 //BA.debugLineNum = 11;BA.debugLine="Private ImageView1 As ImageView";
_imageview1 = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private ImageView2 As ImageView";
_imageview2 = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private ImageView3 As ImageView";
_imageview3 = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
}
